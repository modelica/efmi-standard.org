/*
 * Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 */

#ifndef FLOAT_PRECISION_H
#define FLOAT_PRECISION_H

/* != 0 => single (Float32)
 * 0 => double (Float64)
 */
#define REAL_IS_SINGLE_INSTEAD_OF_DOUBLE 1

#endif /* FLOAT_PRECISION_H */
