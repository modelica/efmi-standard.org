/**************************************************************************************************\
 *** 
 *** Codefile             : tl_userblock.c
 ***
 *** Generation date: 2021-03-08 10:44:29 by TargetLink, the dSPACE production quality code generator
 ***
 *** Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 ***
 *** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 ***
\**************************************************************************************************/

#ifndef TL_USERBLOCK_C
#define TL_USERBLOCK_C

/*------------------------------------------------------------------------------------------------*\
  DEFINES (OPT)
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

#include "builtin_functions/TL_standard_mathematics.h"
#include "builtin_functions/TL_saturation.h"
#include "builtin_functions/TL_error_signals.h"
#include "tl_userblock.h"

/*------------------------------------------------------------------------------------------------*\
  ENUMS
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  DEFINES
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  TYPEDEFS
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  VARIABLES
\*------------------------------------------------------------------------------------------------*/

/**************************************************************************************************\
   EFMU_ERROR_STATUS: Variable class | Width: 32
\**************************************************************************************************/
UInt32 eFMU_ErrorSignalStatus;

/**************************************************************************************************\
   EFMU_STRUCT_DEPPARAM_STATE: Variable class | Width: N.A.
\**************************************************************************************************/
static EFMU_dependentParameter_t eFMU_dependentParameter = {
   -1230., /* C_PI__yMin_ */
   0.8, /* C_PI__I__k_ */
   -0.010222858311183806, /* C_PI__gainTrack__k_ */
   0.0001, /* C_approxPlant__driveline__J_M_ */
   322.16744354201768, /* C_filter__w_ */
   0.1 /* C_gear1__k_ */
};
static EFMU_state_t eFMU_state = {
   0., /* C_PI__y_ */
   0., /* C_derivative_PI__I__y__ */
   0., /* C_PI__I__u_ */
   0., /* C_PI__I__y_ */
   0., /* C_PI__P__y_ */
   0., /* C_PI__addI__u3_ */
   0., /* C_PI__addP__y_ */
   0., /* C_PI__addSat__y_ */
   0., /* C_PI__gainPI__u_ */
   0., /* C_PI__gainPI__y_ */
   0., /* C_PI__limiter__u_ */
   0., /* C_derivative_a__Gear__phi_rel__ */
   0., /* C_derivative_a____Gear__tau_c__ */
   0., /* C_derivative_a____Gear__tau_d__ */
   0., /* C_derivative_a____Gear__w_rel__ */
   0., /* C_approxPlant____Gear__phi_rel_ */
   0., /* C_approxPlant___e__Gear__tau_c_ */
   0., /* C_approxPlant___e__Gear__tau_d_ */
   0., /* C_derivative_a__flange_b__tau__ */
   0., /* C_approxPlant____flange_b__tau_ */
   0., /* C_derivative_a__rivelineIn__w__ */
   0., /* C_approxPlant___flange_b__tau_0 */
   0., /* C_derivative_a____flange__tau__ */
   0., /* C_approxPlant___t__flange__tau_ */
   0., /* C_derivative_filter__x_1___ */
   0., /* C_derivative_filter__x_2___ */
   0., /* C_filter__x_1__ */
   0., /* C_filter__x_2__ */
   0., /* C_gear__u_ */
   0. /* C_gear__y_ */
};

/**************************************************************************************************\
   EFMU_STRUCT_INOUT: Variable class | Width: N.A.
\**************************************************************************************************/
EFMU_input_t eFMU_input = {
   0., /* M_desired */
   0. /* wRel */
};
EFMU_output_t eFMU_output = {
   0. /* M_motor */
};

/**************************************************************************************************\
   EFMU_STRUCT_TUNPARAM: Variable class | Width: N.A.
\**************************************************************************************************/
EFMU_tunableParameter_t eFMU_tunableParameter = {
   0.01, /* J_M */
   1.34, /* Ni_PI */
   1.25, /* Ti_PI */
   4710., /* c_res */
   1.57, /* d_res */
   33., /* f_cut */
   10., /* gearRatio */
   -73., /* k_PI */
   -0.010161521638781401, /* k_accCor */
   1230. /* tauM_max */
};

/*------------------------------------------------------------------------------------------------*\
  PARAMETERIZED MACROS
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  FUNCTION PROTOTYPES
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  INLINE FUNCTIONS
\*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*\
  FUNCTION DEFINITIONS
\*------------------------------------------------------------------------------------------------*/

/**************************************************************************************************\
 ***  FUNCTION:
 ***      DoStep
 *** 
 ***  DESCRIPTION:
 ***      
 *** 
 ***  PARAMETERS:
 ***      Type               Name                Description
 ***      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***
 ***  RETURNS:
 ***      void
 ***
 ***  SETTINGS:
 ***
\**************************************************************************************************/
void DoStep(void)
{
   /* OPT_LOCAL: local variables which are fully optimizable (RAM) | Width: 64 */
   Real _solution_buffer__for__x_;

   eFMU_ErrorSignalStatus = 0;
   eFMU_input.M_desired = dstl_RealSATb(eFMU_input.M_desired, -1000000., 1000000.);
   eFMU_input.wRel = dstl_RealSATb(eFMU_input.wRel, -10000., 10000.);
   eFMU_state.C_filter__x_2__ = eFMU_state.C_filter__x_2__ + (0.0005 *
    eFMU_state.C_derivative_filter__x_2___);
   eFMU_state.C_approxPlant____Gear__phi_rel_ = eFMU_state.C_approxPlant____Gear__phi_rel_ + (0.0005
    * eFMU_state.C_derivative_a__Gear__phi_rel__);
   eFMU_state.C_filter__x_1__ = eFMU_state.C_filter__x_1__ + (0.0005 *
    eFMU_state.C_derivative_filter__x_1___);
   eFMU_state.C_PI__I__y_ = eFMU_state.C_PI__I__y_ + (0.0005 * eFMU_state.C_derivative_PI__I__y__);
   eFMU_state.C_derivative_filter__x_2___ = (eFMU_state.C_filter__x_1__ -
    eFMU_state.C_filter__x_2__) * eFMU_dependentParameter.C_filter__w_;
   eFMU_state.C_derivative_a____flange__tau__ = -(eFMU_tunableParameter.k_accCor *
    eFMU_state.C_derivative_filter__x_2___);
   eFMU_state.C_derivative_a__flange_b__tau__ = -(eFMU_state.C_derivative_filter__x_2___ +
    eFMU_state.C_derivative_a____flange__tau__);
   eFMU_state.C_approxPlant___t__flange__tau_ = -(eFMU_tunableParameter.k_accCor *
    eFMU_state.C_filter__x_2__);
   eFMU_state.C_approxPlant____flange_b__tau_ = -(eFMU_state.C_filter__x_2__ +
    eFMU_state.C_approxPlant___t__flange__tau_);
   eFMU_state.C_approxPlant___e__Gear__tau_c_ = eFMU_tunableParameter.c_res *
    eFMU_state.C_approxPlant____Gear__phi_rel_;
   eFMU_state.C_approxPlant___e__Gear__tau_d_ = eFMU_state.C_approxPlant____flange_b__tau_ -
    eFMU_state.C_approxPlant___e__Gear__tau_c_;
   _solution_buffer__for__x_ = eFMU_state.C_approxPlant___e__Gear__tau_d_ /
    eFMU_tunableParameter.d_res;
   if ((dstl_isNaN(_solution_buffer__for__x_)) || (dstl_isInfinite(_solution_buffer__for__x_))) {
      dstl_set_error_signals(eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED, &eFMU_ErrorSignalStatus);
   }
   else {
      eFMU_state.C_derivative_a__Gear__phi_rel__ = _solution_buffer__for__x_;
   }
   eFMU_state.C_derivative_a____Gear__tau_c__ = eFMU_tunableParameter.c_res *
    eFMU_state.C_derivative_a__Gear__phi_rel__;
   eFMU_state.C_derivative_a____Gear__tau_d__ = eFMU_state.C_derivative_a__flange_b__tau__ -
    eFMU_state.C_derivative_a____Gear__tau_c__;
   _solution_buffer__for__x_ = eFMU_state.C_derivative_a____Gear__tau_d__ /
    eFMU_tunableParameter.d_res;
   if ((dstl_isNaN(_solution_buffer__for__x_)) || (dstl_isInfinite(_solution_buffer__for__x_))) {
      dstl_set_error_signals(eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED, &eFMU_ErrorSignalStatus);
   }
   else {
      eFMU_state.C_derivative_a____Gear__w_rel__ = _solution_buffer__for__x_;
   }
   eFMU_state.C_derivative_a__rivelineIn__w__ = -(eFMU_tunableParameter.gearRatio *
    eFMU_state.C_derivative_a____Gear__w_rel__);
   _solution_buffer__for__x_ = eFMU_state.C_approxPlant____flange_b__tau_ /
    eFMU_tunableParameter.gearRatio;
   if ((dstl_isNaN(_solution_buffer__for__x_)) || (dstl_isInfinite(_solution_buffer__for__x_))) {
      dstl_set_error_signals(eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED, &eFMU_ErrorSignalStatus);
   }
   else {
      eFMU_state.C_approxPlant___flange_b__tau_0 = _solution_buffer__for__x_;
   }
   eFMU_state.C_gear__u_ = (eFMU_dependentParameter.C_approxPlant__driveline__J_M_ *
    eFMU_state.C_derivative_a__rivelineIn__w__) - eFMU_state.C_approxPlant___flange_b__tau_0;
   eFMU_state.C_gear__y_ = eFMU_tunableParameter.gearRatio * eFMU_state.C_gear__u_;
   eFMU_state.C_PI__addP__y_ = eFMU_state.C_derivative_a__Gear__phi_rel__ + (-1. * eFMU_input.wRel);
   eFMU_state.C_PI__P__y_ = eFMU_state.C_PI__addP__y_;
   eFMU_state.C_PI__gainPI__u_ = eFMU_state.C_PI__P__y_ + eFMU_state.C_PI__I__y_;
   eFMU_state.C_PI__gainPI__y_ = eFMU_tunableParameter.k_PI * eFMU_state.C_PI__gainPI__u_;
   eFMU_state.C_PI__limiter__u_ = eFMU_state.C_gear__y_ + eFMU_state.C_PI__gainPI__y_;
   if (eFMU_state.C_PI__limiter__u_ > eFMU_tunableParameter.tauM_max) {
      eFMU_state.C_PI__y_ = eFMU_tunableParameter.tauM_max;
   }
   else {
      if (eFMU_state.C_PI__limiter__u_ < eFMU_dependentParameter.C_PI__yMin_) {
         eFMU_state.C_PI__y_ = eFMU_dependentParameter.C_PI__yMin_;
      }
      else {
         eFMU_state.C_PI__y_ = eFMU_state.C_PI__limiter__u_;
      }
   }
   eFMU_output.M_motor = eFMU_dependentParameter.C_gear1__k_ * eFMU_state.C_PI__y_;
   eFMU_state.C_derivative_filter__x_1___ = (eFMU_input.M_desired - eFMU_state.C_filter__x_1__) *
    eFMU_dependentParameter.C_filter__w_;
   eFMU_state.C_PI__addSat__y_ = (-1. * eFMU_state.C_PI__limiter__u_) + eFMU_state.C_PI__y_;
   eFMU_state.C_PI__addI__u3_ = eFMU_dependentParameter.C_PI__gainTrack__k_ *
    eFMU_state.C_PI__addSat__y_;
   eFMU_state.C_PI__I__u_ = eFMU_state.C_derivative_a__Gear__phi_rel__ + (-1. * eFMU_input.wRel) +
    eFMU_state.C_PI__addI__u3_;
   eFMU_state.C_derivative_PI__I__y__ = eFMU_dependentParameter.C_PI__I__k_ *
    eFMU_state.C_PI__I__u_;
   eFMU_output.M_motor = dstl_RealSATb(eFMU_output.M_motor, -1000000., 1000000.);
   eFMU_state.C_PI__I__y_ = dstl_RealSATb(eFMU_state.C_PI__I__y_, -10000., 10000.);
}

/**************************************************************************************************\
 ***  FUNCTION:
 ***      Recalibrate
 *** 
 ***  DESCRIPTION:
 ***      
 *** 
 ***  PARAMETERS:
 ***      Type               Name                Description
 ***      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***
 ***  RETURNS:
 ***      void
 ***
 ***  SETTINGS:
 ***
\**************************************************************************************************/
void Recalibrate(void)
{
   eFMU_ErrorSignalStatus = 0;
   eFMU_tunableParameter.Ni_PI = dstl_RealSATl(eFMU_tunableParameter.Ni_PI, 1e-13);
   eFMU_tunableParameter.Ti_PI = dstl_RealSATl(eFMU_tunableParameter.Ti_PI, 1e-60);
   eFMU_tunableParameter.c_res = dstl_RealSATl(eFMU_tunableParameter.c_res, 0.);
   eFMU_tunableParameter.d_res = dstl_RealSATl(eFMU_tunableParameter.d_res, 0.);
   eFMU_dependentParameter.C_PI__yMin_ = -eFMU_tunableParameter.tauM_max;
   eFMU_dependentParameter.C_PI__I__k_ = 1. / eFMU_tunableParameter.Ti_PI;
   eFMU_dependentParameter.C_PI__gainTrack__k_ = 1. / (eFMU_tunableParameter.k_PI *
    eFMU_tunableParameter.Ni_PI);
   eFMU_dependentParameter.C_gear1__k_ = 1. / eFMU_tunableParameter.gearRatio;
   eFMU_dependentParameter.C_filter__w_ = (6.2831853071795862 * eFMU_tunableParameter.f_cut) /
    0.6435942529055827;
   eFMU_dependentParameter.C_approxPlant__driveline__J_M_ = eFMU_tunableParameter.J_M /
    (eFMU_tunableParameter.gearRatio * eFMU_tunableParameter.gearRatio);
   eFMU_dependentParameter.C_approxPlant__driveline__J_M_ =
    dstl_RealSATl(eFMU_dependentParameter.C_approxPlant__driveline__J_M_, 0.);
}

/**************************************************************************************************\
 ***  FUNCTION:
 ***      Startup
 *** 
 ***  DESCRIPTION:
 ***      
 *** 
 ***  PARAMETERS:
 ***      Type               Name                Description
 ***      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***
 ***  RETURNS:
 ***      void
 ***
 ***  SETTINGS:
 ***
\**************************************************************************************************/
void Startup(void)
{
   /* OPT_LOCAL: local variables which are fully optimizable (RAM) | Width: 64 */
   Real _solution_buffer__for__x_;

   /* Local: Default storage class for local variables | Width: 32 */
   UInt32 backupErrorSignalStatus;

   eFMU_ErrorSignalStatus = 0;
   eFMU_input.M_desired = 0.;
   eFMU_input.wRel = 0.;
   eFMU_output.M_motor = 0.;
   eFMU_state.C_derivative_filter__x_1___ = 0.;
   eFMU_state.C_derivative_PI__I__y__ = 0.;
   eFMU_state.C_PI__addSat__y_ = 0.;
   eFMU_state.C_PI__addI__u3_ = 0.;
   eFMU_state.C_PI__I__u_ = 0.;
   eFMU_tunableParameter.k_accCor = -0.010161521638781401;
   eFMU_tunableParameter.c_res = 4710.;
   eFMU_tunableParameter.d_res = 1.57;
   eFMU_tunableParameter.gearRatio = 10.;
   eFMU_tunableParameter.k_PI = -73.;
   eFMU_tunableParameter.tauM_max = 1230.;
   eFMU_tunableParameter.J_M = 0.01;
   eFMU_tunableParameter.f_cut = 33.;
   eFMU_tunableParameter.Ni_PI = 1.34;
   eFMU_tunableParameter.Ti_PI = 1.25;
   backupErrorSignalStatus = eFMU_ErrorSignalStatus;
   Recalibrate();
   eFMU_ErrorSignalStatus = (UInt32) (eFMU_ErrorSignalStatus | backupErrorSignalStatus);

   /* # combined # Struct member 'C_filter__x_start_2__' (used as 'eFMU_constant.C_filter__x_start_2
      __') replaced by 'Aux__b' */
   eFMU_state.C_filter__x_2__ = 0.;
   eFMU_state.C_approxPlant____Gear__phi_rel_ = 0.;

   /* # combined # Struct member 'C_filter__x_start_1__' (used as 'eFMU_constant.C_filter__x_start_1
      __') replaced by 'Aux__a' */
   eFMU_state.C_filter__x_1__ = 0.;

   /* # combined # Struct member 'C_PI__xi_start_' (used as 'eFMU_constant.C_PI__xi_start_') replace
      d by 'Aux_' */
   eFMU_state.C_PI__I__y_ = 0.;
   eFMU_state.C_derivative_filter__x_2___ = (eFMU_state.C_filter__x_1__ -
    eFMU_state.C_filter__x_2__) * eFMU_dependentParameter.C_filter__w_;
   eFMU_state.C_derivative_a____flange__tau__ = -(eFMU_tunableParameter.k_accCor *
    eFMU_state.C_derivative_filter__x_2___);
   eFMU_state.C_derivative_a__flange_b__tau__ = -(eFMU_state.C_derivative_filter__x_2___ +
    eFMU_state.C_derivative_a____flange__tau__);
   eFMU_state.C_approxPlant___t__flange__tau_ = -(eFMU_tunableParameter.k_accCor *
    eFMU_state.C_filter__x_2__);
   eFMU_state.C_approxPlant____flange_b__tau_ = -(eFMU_state.C_filter__x_2__ +
    eFMU_state.C_approxPlant___t__flange__tau_);
   eFMU_state.C_approxPlant___e__Gear__tau_c_ = eFMU_tunableParameter.c_res *
    eFMU_state.C_approxPlant____Gear__phi_rel_;
   eFMU_state.C_approxPlant___e__Gear__tau_d_ = eFMU_state.C_approxPlant____flange_b__tau_ -
    eFMU_state.C_approxPlant___e__Gear__tau_c_;
   _solution_buffer__for__x_ = eFMU_state.C_approxPlant___e__Gear__tau_d_ /
    eFMU_tunableParameter.d_res;
   if ((dstl_isNaN(_solution_buffer__for__x_)) || (dstl_isInfinite(_solution_buffer__for__x_))) {
      eFMU_state.C_derivative_a__Gear__phi_rel__ = 0.;
      dstl_set_error_signals(eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED, &eFMU_ErrorSignalStatus);
   }
   else {
      eFMU_state.C_derivative_a__Gear__phi_rel__ = _solution_buffer__for__x_;
   }
   eFMU_state.C_derivative_a____Gear__tau_c__ = eFMU_tunableParameter.c_res *
    eFMU_state.C_derivative_a__Gear__phi_rel__;
   eFMU_state.C_derivative_a____Gear__tau_d__ = eFMU_state.C_derivative_a__flange_b__tau__ -
    eFMU_state.C_derivative_a____Gear__tau_c__;
   _solution_buffer__for__x_ = eFMU_state.C_derivative_a____Gear__tau_d__ /
    eFMU_tunableParameter.d_res;
   if ((dstl_isNaN(_solution_buffer__for__x_)) || (dstl_isInfinite(_solution_buffer__for__x_))) {
      eFMU_state.C_derivative_a____Gear__w_rel__ = 0.;
      dstl_set_error_signals(eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED, &eFMU_ErrorSignalStatus);
   }
   else {
      eFMU_state.C_derivative_a____Gear__w_rel__ = _solution_buffer__for__x_;
   }
   eFMU_state.C_derivative_a__rivelineIn__w__ = -(eFMU_tunableParameter.gearRatio *
    eFMU_state.C_derivative_a____Gear__w_rel__);
   _solution_buffer__for__x_ = eFMU_state.C_approxPlant____flange_b__tau_ /
    eFMU_tunableParameter.gearRatio;
   if ((dstl_isNaN(_solution_buffer__for__x_)) || (dstl_isInfinite(_solution_buffer__for__x_))) {
      eFMU_state.C_approxPlant___flange_b__tau_0 = 0.;
      dstl_set_error_signals(eFMU_err_SOLVE_LINEAR_EQUATIONS_FAILED, &eFMU_ErrorSignalStatus);
   }
   else {
      eFMU_state.C_approxPlant___flange_b__tau_0 = _solution_buffer__for__x_;
   }
   eFMU_state.C_gear__u_ = (eFMU_dependentParameter.C_approxPlant__driveline__J_M_ *
    eFMU_state.C_derivative_a__rivelineIn__w__) - eFMU_state.C_approxPlant___flange_b__tau_0;
   eFMU_state.C_gear__y_ = eFMU_tunableParameter.gearRatio * eFMU_state.C_gear__u_;
   eFMU_state.C_PI__addP__y_ = eFMU_state.C_derivative_a__Gear__phi_rel__ + (-1. * eFMU_input.wRel);
   eFMU_state.C_PI__P__y_ = eFMU_state.C_PI__addP__y_;
   eFMU_state.C_PI__gainPI__u_ = eFMU_state.C_PI__P__y_ + eFMU_state.C_PI__I__y_;
   eFMU_state.C_PI__gainPI__y_ = eFMU_tunableParameter.k_PI * eFMU_state.C_PI__gainPI__u_;
   eFMU_state.C_PI__limiter__u_ = eFMU_state.C_gear__y_ + eFMU_state.C_PI__gainPI__y_;
   if (eFMU_state.C_PI__limiter__u_ > eFMU_tunableParameter.tauM_max) {
      eFMU_state.C_PI__y_ = eFMU_tunableParameter.tauM_max;
   }
   else {
      if (eFMU_state.C_PI__limiter__u_ < eFMU_dependentParameter.C_PI__yMin_) {
         eFMU_state.C_PI__y_ = eFMU_dependentParameter.C_PI__yMin_;
      }
      else {
         eFMU_state.C_PI__y_ = eFMU_state.C_PI__limiter__u_;
      }
   }
   eFMU_input.M_desired = dstl_RealSATb(eFMU_input.M_desired, -1000000., 1000000.);
   eFMU_input.wRel = dstl_RealSATb(eFMU_input.wRel, -10000., 10000.);
   eFMU_output.M_motor = dstl_RealSATb(eFMU_output.M_motor, -1000000., 1000000.);
   eFMU_tunableParameter.Ni_PI = dstl_RealSATl(eFMU_tunableParameter.Ni_PI, 1e-13);
   eFMU_tunableParameter.Ti_PI = dstl_RealSATl(eFMU_tunableParameter.Ti_PI, 1e-60);
   eFMU_tunableParameter.c_res = dstl_RealSATl(eFMU_tunableParameter.c_res, 0.);
   eFMU_tunableParameter.d_res = dstl_RealSATl(eFMU_tunableParameter.d_res, 0.);
   eFMU_state.C_PI__I__y_ = dstl_RealSATb(eFMU_state.C_PI__I__y_, -10000., 10000.);
   eFMU_dependentParameter.C_approxPlant__driveline__J_M_ =
    dstl_RealSATl(eFMU_dependentParameter.C_approxPlant__driveline__J_M_, 0.);
}

/*------------------------------------------------------------------------------------------------*\
  MODULE LOCAL FUNCTION DEFINITIONS
\*------------------------------------------------------------------------------------------------*/
#endif /* TL_USERBLOCK_C */
/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
