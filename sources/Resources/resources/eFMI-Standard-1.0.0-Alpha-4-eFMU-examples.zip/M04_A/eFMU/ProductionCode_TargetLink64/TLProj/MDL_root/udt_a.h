/**************************************************************************************************\
 ***
 *** Codefile             : udt_a.h
 ***
 *** Generation date: 2021-03-08 10:44:29 by TargetLink, the dSPACE production quality code generator
 ***
 *** Copyright (C) 2021 dSPACE GmbH, All rights reserved.
 ***
 *** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 ***
\**************************************************************************************************/

#ifndef UDT_A_H
#define UDT_A_H

#include "tl_basetypes.h"

typedef Float64 Real;

typedef struct EFMU_dependentParameter_t_tag {
   Real C_PI__yMin_;
   Real C_PI__I__k_;
   Real C_PI__gainTrack__k_;
   Real C_approxPlant__driveline__J_M_;
   Real C_filter__w_;
   Real C_gear1__k_;
} EFMU_dependentParameter_t;

typedef struct EFMU_input_t_tag {
   Real M_desired;
   Real wRel;
} EFMU_input_t;

typedef struct EFMU_output_t_tag {
   Real M_motor;
} EFMU_output_t;

typedef struct EFMU_state_t_tag {
   Real C_PI__y_;
   Real C_derivative_PI__I__y__;
   Real C_PI__I__u_;
   Real C_PI__I__y_;
   Real C_PI__P__y_;
   Real C_PI__addI__u3_;
   Real C_PI__addP__y_;
   Real C_PI__addSat__y_;
   Real C_PI__gainPI__u_;
   Real C_PI__gainPI__y_;
   Real C_PI__limiter__u_;
   Real C_derivative_a__Gear__phi_rel__;
   Real C_derivative_a____Gear__tau_c__;
   Real C_derivative_a____Gear__tau_d__;
   Real C_derivative_a____Gear__w_rel__;
   Real C_approxPlant____Gear__phi_rel_;
   Real C_approxPlant___e__Gear__tau_c_;
   Real C_approxPlant___e__Gear__tau_d_;
   Real C_derivative_a__flange_b__tau__;
   Real C_approxPlant____flange_b__tau_;
   Real C_derivative_a__rivelineIn__w__;
   Real C_approxPlant___flange_b__tau_0;
   Real C_derivative_a____flange__tau__;
   Real C_approxPlant___t__flange__tau_;
   Real C_derivative_filter__x_1___;
   Real C_derivative_filter__x_2___;
   Real C_filter__x_1__;
   Real C_filter__x_2__;
   Real C_gear__u_;
   Real C_gear__y_;
} EFMU_state_t;

typedef struct EFMU_tunableParameter_t_tag {
   Real J_M;
   Real Ni_PI;
   Real Ti_PI;
   Real c_res;
   Real d_res;
   Real f_cut;
   Real gearRatio;
   Real k_PI;
   Real k_accCor;
   Real tauM_max;
} EFMU_tunableParameter_t;

#endif /* UDT_A_H */
/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
